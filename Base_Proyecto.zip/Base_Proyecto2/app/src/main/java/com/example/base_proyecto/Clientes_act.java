package com.example.base_proyecto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

import planes.Planes;

public class Clientes_act extends AppCompatActivity {
    private Spinner spin1;
    private Spinner spin2;
    private EditText edit;
    private TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clientes_act);

        spin1=(Spinner)findViewById(R.id.spnClientes);
        spin2=(Spinner)findViewById(R.id.spnPlanes);
        edit=(EditText)findViewById(R.id.et1);
        text=(TextView)findViewById(R.id.tv);

        ArrayList<String> listaClientes= (ArrayList<String>)(getIntent().getSerializableExtra("listaClientes"));
        ArrayList<String> listaPlanes = (ArrayList<String>)(getIntent().getSerializableExtra("listaPlanes"));

        ArrayAdapter<String> adapt= new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,listaClientes);
        ArrayAdapter<String> adapts = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,listaPlanes);

        spin1.setAdapter(adapt);
        spin2.setAdapter(adapts);
    }

    public void  Calcular(View view){
        Planes pl=new Planes();

        String clientes=spin1.getSelectedItem().toString();
        String planes =spin2.getSelectedItem().toString();

        int montant=Integer.parseInt(edit.getText().toString());
        if (clientes.equals("Roberto") && planes.equals("XTREME")){
            int resultM=pl.getxTreme()-montant;
            text.setText("Le montant est : "+resultM);
        }
        if (clientes.equals("Roberto") && planes.equals("MINDFULLNESS")){
            int resultM=pl.getMindfullness()-montant;
            text.setText("Le montant est : "+resultM);
        }

        if (clientes.equals("Richard")&&planes.equals("XTREME")){
            int resultM=pl.getxTreme()-montant;
            text.setText("Le montant est : "+resultM);
        }

        if (clientes.equals("Richard") && planes.equals("MINDFULLNESS")){
            int resultM=pl.getMindfullness()-montant;
            text.setText("Le montant est : "+resultM);
        }

    }
}