package com.example.base_proyecto;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ViewFlipper;

import java.util.ArrayList;

public class Home_act extends AppCompatActivity {
    private ViewFlipper vf;
    private int[] image={R.drawable.c,R.drawable.a,R.drawable.b};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_act);

        vf=(ViewFlipper)findViewById(R.id.slider);

        for (int i=0;i<image.length;i++){
            flip_image(image[i]);
        }
    }

    public void flip_image(int i){
        ImageView view= new ImageView(this);
        view.setBackgroundResource(i);

        vf.addView(view);
        vf.setFlipInterval(2500);
        vf.setAutoStart(true);
    }

    public void Maps(View view)
    {
        Intent i=new Intent(this,Maps_act.class);
        startActivity(i);
    }

    public  void Infos(View view)
    {
        Intent i=new Intent(this,Info_act.class);
        startActivity(i);
    }

    public void Clientes(View view)
    {
        ArrayList<String> clientes= new ArrayList<String>();
        ArrayList<String> planes=new ArrayList<String>();

        clientes.add("Roberto");
        clientes.add("Richard");
        clientes.add("Franck");

        planes.add("XTREME");
        planes.add("MINDFULLNESS");

        Intent i=new Intent(this,Clientes_act.class);
        i.putExtra("listaClientes",clientes);
        i.putExtra("listaPlanes",planes);
        startActivity(i);
    }

    public void Insumnos(View view)
    {
        Intent i=new Intent(this,Insumnos_act.class);
        startActivity(i);
    }
}